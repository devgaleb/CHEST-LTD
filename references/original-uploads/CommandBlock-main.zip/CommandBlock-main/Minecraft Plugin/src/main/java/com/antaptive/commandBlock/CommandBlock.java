package com.antaptive.commandBlock;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import io.papermc.paper.ban.BanListType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.earth2me.essentials.*;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

public final class CommandBlock extends JavaPlugin {

    // How long an HTTP request waits for the main server thread before giving up
    private static final long MAIN_THREAD_TIMEOUT_SECONDS = 5;

    private static final Gson GSON = new Gson();

    private HttpServer server;
    private String apiToken;

    private Essentials essentials;

    @Override
    public void onEnable() {
        // Plugin startup logic
        saveDefaultConfig();

        // Make sure config is set properly

        // Don't allow a blank token or the default token "your-secret-token-here"
        String configuredToken = getConfig().getString("api-token", "");
        if (configuredToken.isBlank() || configuredToken.equals("your-secret-token-here")) {
            getLogger().severe("CommandBlock has failed to start: An API token has not been set.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        if (!getConfig().contains("port")) {
            getLogger().severe("CommandBlock has failed to start: A port has not been set.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        apiToken = configuredToken;

        Plugin ess = Bukkit.getPluginManager().getPlugin("Essentials");
        if (ess != null && ess.getPluginMeta().getVersion().compareTo("2.21.0") < 0) {
            getLogger().warning("EssentialsX version too old. We expect at least 2.21.0. Some features have been disabled.");
        }
        else if (ess != null) {
            getLogger().info("EssentialsX has been found!");
            boolean hasEssentials = Bukkit.getPluginManager().isPluginEnabled("Essentials");
            essentials = hasEssentials ? (Essentials) Bukkit.getPluginManager().getPlugin("Essentials") : null;
        }
        else {
            getLogger().info("EssentialsX was not found. Some features have been disabled.");
        }

        this.getCommand("restarthttpserver").setExecutor(new RestartHTTPServer());

        StartHTTPServer();
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        StopHTTPServer();
    }

    public String getFormattedUptime() {
        // Measured from when the server process started, so plugin reloads don't reset it
        long uptimeMillis = ManagementFactory.getRuntimeMXBean().getUptime();
        long seconds = uptimeMillis / 1000;

        long days = seconds / 86400;
        long hours = (seconds % 86400) / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;

        return String.format("%dd %dh %dm %ds", days, hours, minutes, secs);
    }

    /**
     * Starts (or restarts) the HTTP server.
     * @return Whether the server started successfully
     */
    public boolean StartHTTPServer() {
        if (server != null) {
            server.stop(0);
            server = null;
            getLogger().info("HTTP server has stopped and is being restarted");
        }

        int port = getConfig().getInt("port");
        String bindAddress = getConfig().getString("bind-address", "127.0.0.1");

        try {
            server = HttpServer.create(new InetSocketAddress(bindAddress, port), 0);

            // Server control endpoints
            server.createContext("/server/stop", exchange -> {
                if (!handleAuth(exchange)) return;

                if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                    sendError(exchange, 405, "Method not allowed. Use POST");
                    return;
                }

                getLogger().info("Stop command received from " + exchange.getRemoteAddress());

                Bukkit.getScheduler().runTask(this, () -> {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "stop");
                });

                sendSuccess(exchange);
            });

            // Player management endpoints
            server.createContext("/server/player/kick", exchange -> {
                // If the request doesn't have proper authentication
                if (!handleAuth(exchange)) return;

                if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                    sendError(exchange, 405, "Method not allowed. Use POST");
                    return;
                }

                getLogger().info("Kick Player command received from " + exchange.getRemoteAddress());

                Map<String, String> params = parseQuery(exchange);
                if (params == null) return;

                String playerName = requirePlayerName(exchange, params);
                if (playerName == null) return;

                String reason = params.getOrDefault("reason", "");

                try {
                    boolean kicked = callOnMainThread(() -> {
                        Player player = Bukkit.getPlayer(playerName);
                        if (player == null) return false;

                        Component message = Component.text("You have been kicked.", NamedTextColor.RED);

                        if (!reason.isBlank()) {
                            message = message.append(Component.text("\n" + reason, NamedTextColor.YELLOW));
                        }

                        player.kick(message);
                        return true;
                    });

                    if (kicked) {
                        getLogger().info(playerName + " was kicked.");
                        sendSuccess(exchange);
                    }
                    else {
                        sendError(exchange, 400, "The player is not online");
                        getLogger().warning("Request tried to kick " + playerName + " but the player was not online.");
                    }
                }
                catch (Exception e) {
                    sendError(exchange, 400, describe(e));
                    getLogger().severe("Error kicking " + playerName + ": " + describe(e));
                }

            });

            server.createContext("/server/player/ban", exchange -> {
                // If the request doesn't have proper authentication
                if (!handleAuth(exchange)) return;

                if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                    sendError(exchange, 405, "Method not allowed. Use POST");
                    return;
                }

                getLogger().info("Ban Player command received from " + exchange.getRemoteAddress());

                Map<String, String> params = parseQuery(exchange);
                if (params == null) return;

                String playerName = requirePlayerName(exchange, params);
                if (playerName == null) return;

                String reason = params.getOrDefault("reason", "");

                try {
                    callOnMainThread(() -> {
                        Component message = Component.text("You have been banned.", NamedTextColor.RED);

                        if (!reason.isBlank()) {
                            message = message.append(Component.text("\n" + reason, NamedTextColor.YELLOW));
                        }

                        Bukkit.getBanList(BanListType.PROFILE).addBan(
                                playerName,
                                reason,
                                null,
                                null
                        );

                        // Adding to the banlist doesn't kick the player, so give them a friendly shove.
                        Player player = Bukkit.getPlayer(playerName);
                        if (player != null) {
                            player.kick(message);
                        }

                        return null;
                    });

                    sendSuccess(exchange);
                    getLogger().info(playerName + " was banned.");
                }
                catch (Exception e) {
                    sendError(exchange, 400, describe(e));
                    getLogger().severe("Error banning " + playerName + ": " + describe(e));
                }

            });

            server.createContext("/server/player/unban", exchange -> {
                // If the request doesn't have proper authentication
                if (!handleAuth(exchange)) return;

                if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                    sendError(exchange, 405, "Method not allowed. Use POST");
                    return;
                }

                getLogger().info("Unban Player command received from " + exchange.getRemoteAddress());

                Map<String, String> params = parseQuery(exchange);
                if (params == null) return;

                String playerName = requirePlayerName(exchange, params);
                if (playerName == null) return;

                try {
                    // Looking up an offline player can block on a web request, so do it off the main thread
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerName);
                    PlayerProfile player = Bukkit.createProfile(offlinePlayer.getUniqueId(), playerName);

                    boolean unbanned = callOnMainThread(() -> {
                        var banList = Bukkit.getBanList(BanListType.PROFILE);
                        if (!banList.isBanned(player)) return false;

                        banList.pardon(player);
                        return true;
                    });

                    if (unbanned) {
                        getLogger().info(playerName + " was unbanned.");
                        sendSuccess(exchange);
                    }
                    else {
                        sendError(exchange, 400, "Player is not banned.");
                        getLogger().warning("Request was denied since the player '" + playerName + "' is not banned.");
                    }
                }
                catch (Exception e) {
                    sendError(exchange, 400, describe(e));
                    getLogger().severe("Error unbanning " + playerName + ": " + describe(e));
                }

            });

            // TODO: Force whitelist to work only if the user exists. Also, return the
            // ACTUAL username of who got whitelisted.
            server.createContext("/server/player/whitelist/add", exchange -> {
                // If the request doesn't have proper authentication
                if (!handleAuth(exchange)) return;

                if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                    sendError(exchange, 405, "Method not allowed. Use POST");
                    return;
                }

                getLogger().info("Whitelist Add Player command received from " + exchange.getRemoteAddress());

                Map<String, String> params = parseQuery(exchange);
                if (params == null) return;

                String playerName = requirePlayerName(exchange, params);
                if (playerName == null) return;

                try {
                    // Looking up an offline player can block on a web request, so do it off the main thread
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerName);

                    callOnMainThread(() -> {
                        offlinePlayer.setWhitelisted(true);
                        return null;
                    });

                    getLogger().info(playerName + " was whitelisted.");
                    sendSuccess(exchange);
                }
                catch (Exception e) {
                    sendError(exchange, 400, describe(e));
                    getLogger().severe("Error whitelisting " + playerName + ": " + describe(e));
                }

            });

            server.createContext("/server/player/whitelist/remove", exchange -> {
                // If the request doesn't have proper authentication
                if (!handleAuth(exchange)) return;

                if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                    sendError(exchange, 405, "Method not allowed. Use POST");
                    return;
                }

                getLogger().info("Whitelist Remove Player command received from " + exchange.getRemoteAddress());

                Map<String, String> params = parseQuery(exchange);
                if (params == null) return;

                String playerName = requirePlayerName(exchange, params);
                if (playerName == null) return;

                try {
                    // Looking up an offline player can block on a web request, so do it off the main thread
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerName);

                    callOnMainThread(() -> {
                        offlinePlayer.setWhitelisted(false);

                        Player player = Bukkit.getPlayer(playerName);

                        if (player != null) {
                            Component message = Component.text("You have been removed from the whitelist and kicked.", NamedTextColor.RED);
                            player.kick(message);
                        }

                        return null;
                    });

                    getLogger().info(playerName + " was removed from the whitelist and kicked.");
                    sendSuccess(exchange);
                }
                catch (Exception e) {
                    sendError(exchange, 400, describe(e));
                    getLogger().severe("Error removing " + playerName + " from whitelist: " + describe(e));
                }

            });

            server.createContext("/server/stats", exchange -> {
                // If the request doesn't have proper authentication
                if (!handleAuth(exchange)) return;

                if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
                    sendError(exchange, 405, "Method not allowed. Use GET");
                    return;
                }

                getLogger().info("Server stats request received from " + exchange.getRemoteAddress());

                Map<String, Object> stats;

                try {
                    // Player and server state must be read on the main thread
                    stats = callOnMainThread(() -> {
                        List<String> playerList = new ArrayList<>();

                        for (Player p : Bukkit.getOnlinePlayers()) {
                            int ping = p.getPing();
                            String name = p.getName();

                            boolean isAfk = false;
                            if (essentials != null) {
                                com.earth2me.essentials.User user = essentials.getUser(p);
                                if (user != null) isAfk = user.isAfk();
                            }

                            String display = name + (isAfk ? " (AFK)" : "") + " [" + ping + "ms]";
                            playerList.add(display);
                        }

                        Map<String, Object> result = new HashMap<>();
                        result.put("gameVersion", Bukkit.getMinecraftVersion());
                        result.put("uptime", getFormattedUptime());
                        result.put("onlinePlayers", Bukkit.getOnlinePlayers().size());
                        result.put("maxPlayers", Bukkit.getMaxPlayers());
                        result.put("tps", getServer().getTPS()[0]);
                        result.put("playerList", playerList);
                        return result;
                    });
                }
                catch (Exception e) {
                    sendError(exchange, 500, describe(e));
                    getLogger().severe("Error getting server stats: " + describe(e));
                    return;
                }

                sendResponse(exchange, 200, GSON.toJson(stats));
            });

            server.setExecutor(null);
            server.start();
            getLogger().info("HTTP server started on " + bindAddress + ":" + port);
            return true;

        } catch (Exception e) {
            server = null;
            getLogger().severe("Failed to start HTTP Server: " + e.getMessage());
            return false;
        }
    }

    public void StopHTTPServer() {
        if (server != null) {
            server.stop(0);
            server = null;
        }
    }

    /**
     * Runs a task on the main server thread and waits for its result.
     * The Bukkit API is not thread-safe, but HTTP requests are handled on their own thread.
     */
    private <T> T callOnMainThread(@NotNull Callable<T> task) throws Exception {
        try {
            return Bukkit.getScheduler().callSyncMethod(this, task).get(MAIN_THREAD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        }
        catch (java.util.concurrent.ExecutionException e) {
            // Unwrap so the original error is reported
            Throwable cause = e.getCause();
            throw cause instanceof Exception ? (Exception) cause : e;
        }
    }

    private static String describe(@NotNull Exception e) {
        if (e instanceof java.util.concurrent.TimeoutException) {
            return "The server took too long to respond.";
        }
        return e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
    }

    /**
     * Parses the request's query parameters.
     * @return The parameters, or null if there were none (a 400 response has already been sent)
     */
    private @Nullable Map<String, String> parseQuery(@NotNull HttpExchange exchange) throws IOException {
        String query = exchange.getRequestURI().getRawQuery();
        if (query == null || query.isEmpty()) {
            sendError(exchange, 400, "Missing query parameters");
            getLogger().warning("Request was denied for missing query parameters.");
            return null;
        }

        Map<String, String> params = new HashMap<>();
        for (String param : query.split("&")) {
            String[] pair = param.split("=", 2);
            if (pair.length == 2) {
                try {
                    params.put(pair[0], java.net.URLDecoder.decode(pair[1], StandardCharsets.UTF_8));
                } catch (Exception e) {
                    // If decoding fails, use the raw value
                    params.put(pair[0], pair[1]);
                }
            }
        }

        return params;
    }

    /**
     * Gets the required "player" parameter.
     * @return The player name, or null if it was missing (a 400 response has already been sent)
     */
    private @Nullable String requirePlayerName(@NotNull HttpExchange exchange, @NotNull Map<String, String> params) throws IOException {
        String playerName = params.get("player");

        if (playerName == null || playerName.isBlank()) {
            sendError(exchange, 400, "A user was not specified. Please specify a 'player' parameter.");
            getLogger().warning("Request was denied for missing a 'player' parameter.");
            return null;
        }

        return playerName;
    }

    private boolean handleAuth(@NotNull HttpExchange exchange) throws IOException {
        // Check HTTP method
        String method = exchange.getRequestMethod();
        if (!method.equalsIgnoreCase("POST") && !method.equalsIgnoreCase("GET")) {
            sendError(exchange, 405, "Method not allowed");
            getLogger().info(exchange.getRemoteAddress() + " failed authentication: Attempted a " + method + " request.");
            return false;
        }

        // Check authorization
        if (!isAuthorized(exchange)) {
            sendError(exchange, 401, "Unauthorized");
            getLogger().info(exchange.getRemoteAddress() + " failed authentication: Incorrect API token.");
            return false;
        }

        return true;
    }

    // Check if request has valid authorization token
    private boolean isAuthorized(@NotNull HttpExchange exchange) {
        String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
        if (authHeader == null) return false;

        // Expected format: "Bearer TOKEN"
        if (authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            // Constant-time comparison so the token can't be guessed from response timing
            return MessageDigest.isEqual(
                    token.getBytes(StandardCharsets.UTF_8),
                    apiToken.getBytes(StandardCharsets.UTF_8));
        }

        return false;
    }

    private void sendSuccess(@NotNull HttpExchange exchange) throws IOException {
        sendResponse(exchange, 200, GSON.toJson(Map.of("success", true)));
    }

    // Builds the error JSON with Gson so quotes in error messages can't break it
    private void sendError(@NotNull HttpExchange exchange, int statusCode, @NotNull String error) throws IOException {
        sendResponse(exchange, statusCode, GSON.toJson(Map.of("error", error)));
    }

    // Send HTTP response
    private void sendResponse(@NotNull HttpExchange exchange, int statusCode, @NotNull String response) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, bytes.length);

        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    class RestartHTTPServer implements CommandExecutor {
        public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String @NotNull [] args) {
            // Works for players and the console
            if (!sender.hasPermission("commandblock.restarthttpserver")) {
                sender.sendMessage(Component.text("You don't have permission to use this command.", NamedTextColor.RED));
                return true;
            }

            // This method also handles restarting if necessary
            if (StartHTTPServer()) {
                sender.sendMessage(Component.text("HTTP server restarted successfully!", NamedTextColor.GREEN));
            }
            else {
                sender.sendMessage(Component.text("HTTP server failed to restart. Check the server log for details.", NamedTextColor.RED));
            }

            return true;
        }
    }
}
