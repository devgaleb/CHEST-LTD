![CommandBlock Banner](/readme/banner.jpg)
# CommandBlock
An open-source Discord bot to control a Minecraft server.

*This project is not affiliated with, sponsored, or endorsed by Mojang or Discord.*

### [Check out my other projects!](https://antaptive.com/projects)

### Consider supporting the creator!
[Patreon](https://www.patreon.com/c/antaptive) | [Kofi](https://ko-fi.com/antaptive) | [Merch Store](http://shop.antaptive.com)

## License

   This repository contains two separate projects with different licenses:
   
   - **Minecraft Plugin**: GPL v3 (see `Minecraft Plugin/LICENSE`)
   - **Discord Bot**: MIT (see `Discord Bot/LICENSE`)

## Initial Setup
### Minecraft Plugin
1. Install the .jar file into your server's `plugins` folder.
2. Start the server to generate the `config.yml` file which you can find in `plugins/CommandBlock` and open with a text editor.<br>
*It is expected to see CommandBlock fail to start in your server's log.*
3. Change `api-token` in the `config.yml` file.<br>
**Choose something VERY secure. Anyone with this token can ban, kick, or whitelist any player!**
4. Save changes to `config.yml` and restart your Minecraft server.
### Discord Bot
The Discord bot runs on Windows and Linux and requires [Node.js](https://nodejs.org) 22 or newer.

1. Download this repository and open a terminal in the `Discord Bot` folder.
2. Install dependencies and build the bot:
    ```
    npm install
    npm run build
    ```
3. Run `npm start` once. The bot creates `config.env` in the `Discord Bot` folder and exits.
    * You can also copy `config.env.example` to `config.env` yourself.
4. Open `config.env` with a text editor and fill in the required values (see [Configuration](#configuration)).
5. Invite your bot to your master Discord server with the `bot` and `applications.commands` scopes, then start it with `npm start` or [PM2](#running-with-pm2).
6. If the CommandBlock plugin is not running at `http://127.0.0.1:25580`, set `HTTP_SERVER_URL` in `config.env` or run `/set-http-server` on Discord.
    * The HTTP server is **NOT** your Minecraft IP. CommandBlock prints its address to your Minecraft server's log. If the Minecraft server and Discord bot are running on two separate machines, you may need to configure your firewall.
    * You will need to be an administrator in your server to run admin commands. If you're not an admin, get one to run `/add-role` with a role you want to have permission to run CommandBlock's admin commands.
    * If you do not see any commands once the bot has started, press `Ctrl + R` in Discord to refresh your Discord client. Re-invite the bot to your server if you still see no commands.

#### Configuration
`config.env` holds everything the bot needs to start. Restart the bot after changing it.

| Setting | Required | Purpose |
|:---|:---|:---|
| `DISCORD_TOKEN` | Yes | Your Discord bot's token<br>If you don't know how to get your Discord bot token, please check out this tutorial: *(coming soon! for now, please look up how to make a Discord bot)* |
| `MASTER_SERVER_ID` | Yes | The ID of the bot's primary Discord server. The bot always stays in this server, and it can only be changed here. |
| `PLUGIN_API_TOKEN` | Yes | The CommandBlock plugin's API token (`api-token` in the plugin's `config.yml`) |
| `HTTP_SERVER_URL` | No | The CommandBlock plugin's HTTP server. Defaults to `http://127.0.0.1:25580`. |
| `MC_SERVER_IP` | No | The Minecraft server IP displayed to users on Discord. This is **only** for display purposes. |
| `SERVER_START_COMMAND` | No | The command `/start-server` runs. `/start-server` is disabled if this is empty. See [Starting the Minecraft server](#starting-the-minecraft-server).<br>**WARNING:** This can run ANY program on your machine. Set this with caution. |
| `SERVER_START_DIRECTORY` | No | The folder `SERVER_START_COMMAND` runs in, usually your Minecraft server folder. Defaults to the `Discord Bot` folder. |

On Windows, wrap `SERVER_START_DIRECTORY` in single quotes (for example `SERVER_START_DIRECTORY='C:\Minecraft\Server'`) so backslashes are not treated as escape characters.

Settings changed from Discord (extra servers, admin roles, the logging channel, and `/set-http-server` or `/set-mc-server` overrides) are saved by the bot in `data.json`. You should not need to edit it.

#### Running with PM2
[PM2](https://pm2.keymetrics.io) keeps the bot running in the background, restarts it if it crashes, and can start it when your machine boots.
```
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
```
* `pm2 logs commandblock` shows the bot's log, and `pm2 flush commandblock` clears it.
* `pm2 restart commandblock` restarts the bot, and `pm2 stop commandblock` stops it.
* `pm2 startup` prints a command that makes PM2 start on boot.
* If `config.env` is missing a value or the bot token is invalid, the bot exits with code 78 and PM2 will not restart it. Check `pm2 logs commandblock`, fix `config.env`, and run `pm2 restart commandblock`.

Without PM2, `npm start` runs the bot in the current terminal. Press `Ctrl + C` to shut it down.

#### Updating
After downloading a new version, run the following in the `Discord Bot` folder:
```
npm install
npm run build
pm2 restart commandblock
```

#### Starting the Minecraft server
`/start-server` runs `SERVER_START_COMMAND` in `SERVER_START_DIRECTORY`. The command runs separately from the bot, so the Minecraft server keeps running if the bot stops or restarts. `/stop-server` stops the server gracefully through the CommandBlock plugin.

| Platform | Example `SERVER_START_COMMAND` |
|:---|:---|
| Windows | `start.bat` (opens the server in its own console window) |
| Linux | `tmux new-session -d -s minecraft ./start.sh` (attach to the server console with `tmux attach -t minecraft`) |
| Linux with systemd | `XDG_RUNTIME_DIR=/run/user/$(id -u) systemctl --user start minecraft` (see below) |

On Linux, make sure your start script is executable (`chmod +x start.sh`).

##### Optional: running the Minecraft server as a systemd service (Linux)
Running the server as a systemd user service lets systemd manage it and restart it after a crash, without giving the bot root access.

1. Create `~/.config/systemd/user/minecraft.service`, adjusting the paths and memory to fit your server:
    ```ini
    [Unit]
    Description=Minecraft server
    After=network.target

    [Service]
    WorkingDirectory=/home/you/minecraft
    ExecStart=/usr/bin/java -Xms2G -Xmx4G -jar server.jar nogui
    # Only restart after a crash, so /stop-server keeps the server stopped.
    Restart=on-failure
    SuccessExitStatus=0 143

    [Install]
    WantedBy=default.target
    ```
2. Load the service and allow your user services to run while you are logged out:
    ```
    systemctl --user daemon-reload
    loginctl enable-linger $USER
    ```
3. Set `SERVER_START_COMMAND=XDG_RUNTIME_DIR=/run/user/$(id -u) systemctl --user start minecraft` in `config.env` and restart the bot.
    * `XDG_RUNTIME_DIR` lets `systemctl --user` work even when PM2 was started at boot instead of from your login session.
    * Use `Restart=on-failure`, not `Restart=always`. Otherwise systemd starts the server again right after `/stop-server` stops it.

#### Upgrading from 1.x
Version 2.0.0 replaces the Windows-only bot with a cross-platform Node.js bot. `config.json` is no longer used, so set the bot up again with `config.env`. Command names now use hyphens instead of underscores (for example `/server-stats` instead of `/server_stats`).

## Commands
### Minecraft
| Command | Purpose |
|:---|:---|
| `/restarthttpserver` | Restarts the CommandBlock HTTP REST API server<br>Useful if the server ever misbehaves |
### Discord
| Command | Purpose | Usage |
|:---|:---|:---|
| `/server-stats` | Gets the Minecraft's server's statistics, showing the server version, player list & count, uptime, and last TPS. <br>**NOTE:** If something is improperly configured, this command will show the server as "offline" when it may not be. All info will be sent to the Discord bot's log. | Everyone
| `/add-guild` | Adds a guild ID to the list of allowed guilds/servers the bot can be in<br>The master server in `config.env` is always allowed | Admin
| `/remove-guild` | Removes a guild ID from the list of allowed guilds/servers the bot can be in, and leaves that server<br>The master server can't be removed | Admin
| `/add-role` | Adds a role to the list of allowed roles for admin commands | Admin
| `/remove-role` | Removes a role from the list of allowed roles for admin commands | Admin
| `/ban-player` | Bans a player from the minecraft server | Admin
| `/unban-player` | Unbans a player from the minecraft server | Admin
| `/kick-player` | Kicks a player from the minecraft server | Admin
| `/set-http-server` | Sets the CommandBlock HTTP server to communicate to<br>Overrides `HTTP_SERVER_URL` in `config.env` | Admin
| `/set-mc-server` | Sets the IP the bot will display to users on Discord<br>This is **only** for display purposes. Overrides `MC_SERVER_IP` in `config.env` | Admin
| `/set-logging-channel` | Sets the logging channel where important messages will be sent when commands are ran | Admin
| `/remove-logging-channel` | Removes the logging channel and disables logging on Discord | Admin
| `/start-server` | Starts the Minecraft server using `SERVER_START_COMMAND` | Admin
| `/stop-server` | Gracefully stops the Minecraft server | Admin
| `/whitelist-player` | Adds a player to the Minecraft server's whitelist | Admin
| `/unwhitelist-player` | Removes a player from the Minecraft server's whitelist | Admin

## API
CommandBlock starts an HTTP REST API server that can control your Minecraft server.<br>
All requests to any endpoint must include an API token in the following format:
```
Authorization: Bearer <api_token>
```
| Endpoint | Purpose |
|:---|:---|
| `/server/player/ban` | Bans a user from the Minecraft server
| `/server/player/kick` | Kicks a user from the Minecraft server
| `/server/player/unban` | Unbans a user from the Minecraft server
| `/server/player/whitelist/add` | Whitelists a user from the Minecraft server
| `/server/player/whitelist/remove` | Un-whitelists a user from the Minecraft server
| `/server/stats` | Returns a JSON object of the server's current stats<br>(see below for schema)
| `/server/stop` | Stops the Minecraft server
### `/server/stats` Schema
```scheme
{
    "maxPlayers": "integer",
    "onlinePlayers": "integer",
    "tps": "number",
    "playerList": ["string"],
    "gameVersion": "string",
    "uptime": "string"
}
```
