// PM2 configuration. Start the bot with: pm2 start ecosystem.config.js
module.exports = {
    apps: [
        {
            name: "commandblock",
            script: "dist/index.js",
            cwd: __dirname,
            // Back off between restarts if the bot keeps crashing (e.g. Discord is unreachable).
            exp_backoff_restart_delay: 1000,
            max_restarts: 10,
            // Exit code 78 means the configuration is invalid, so restarting would not help.
            stop_exit_codes: [78],
            // Only stop the bot itself. A Minecraft server started with /start-server
            // must keep running when the bot restarts.
            treekill: false,
            kill_timeout: 5000,
        },
    ],
};
