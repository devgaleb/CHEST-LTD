import { describeStatus, sendPost } from "../http";
import { print, printError } from "../log";
import { Color, respond, sendToLogChannel } from "../messages";
import { Command, ranBy, slashCommand } from "./command";

interface PlayerCommandOptions {
    name: string;
    description: string;
    endpoint: string;
    /** e.g. "kick", used in failure messages. */
    verb: string;
    /** e.g. "kicked", used in success messages. */
    pastTense: string;
    /** Set to give the command an optional reason option with this description. */
    reasonDescription?: string;
}

/** Builds a command that sends a player name (and optional reason) to a plugin endpoint. */
function playerCommand(options: PlayerCommandOptions): Command {
    const { verb, pastTense } = options;
    const byLabel = pastTense.charAt(0).toUpperCase() + pastTense.slice(1) + " by";

    const data = slashCommand(options.name, options.description)
        .addStringOption((option) => option
            .setName("player-name")
            .setDescription(`The username of the player to ${verb}`)
            .setRequired(true));

    const { reasonDescription } = options;
    if (reasonDescription) {
        data.addStringOption((option) => option
            .setName("reason")
            .setDescription(reasonDescription));
    }

    return {
        data,
        admin: true,
        ephemeral: true,
        async execute(interaction) {
            const playerName = interaction.options.getString("player-name", true);
            const reason = interaction.options.getString("reason") ?? "";

            const query = new URLSearchParams({ player: playerName });
            if (reasonDescription)
                query.set("reason", reason);

            const response = await sendPost(`${options.endpoint}?${query}`);

            if (response.ok) {
                const message = reason.trim()
                    ? `Successfully ${pastTense} player ${playerName} for reason: ${reason}`
                    : `Successfully ${pastTense} player ${playerName}`;

                await respond(interaction, message, Color.Success);
                print(message);
                await sendToLogChannel(interaction, `${message}\n${ranBy(interaction, byLabel)}`, Color.Success);
            } else {
                const status = describeStatus(response.status);

                await respond(interaction, `Failed to ${verb} player ${playerName}. ${response.error}`, Color.Error);
                printError(`Failed to ${verb} player ${playerName}. Status code: ${status}`);
                await sendToLogChannel(interaction,
                    `Failed to ${verb} player ${playerName}. Status code: ${status}\n${ranBy(interaction, byLabel)}`,
                    Color.Error);
            }
        },
    };
}

export const moderationCommands: Command[] = [
    playerCommand({
        name: "kick-player",
        description: "Kicks a player from the Minecraft server",
        endpoint: "/server/player/kick",
        verb: "kick",
        pastTense: "kicked",
        reasonDescription: "The reason for kicking the player",
    }),
    playerCommand({
        name: "ban-player",
        description: "Bans a player from the Minecraft server",
        endpoint: "/server/player/ban",
        verb: "ban",
        pastTense: "banned",
        reasonDescription: "The reason for banning the player",
    }),
    playerCommand({
        name: "unban-player",
        description: "Unbans a player from the Minecraft server",
        endpoint: "/server/player/unban",
        verb: "unban",
        pastTense: "unbanned",
    }),
    playerCommand({
        name: "whitelist-player",
        description: "Adds a player to the Minecraft server's whitelist",
        endpoint: "/server/player/whitelist/add",
        verb: "whitelist",
        pastTense: "whitelisted",
    }),
    playerCommand({
        name: "unwhitelist-player",
        description: "Removes a player from the Minecraft server's whitelist",
        endpoint: "/server/player/whitelist/remove",
        verb: "unwhitelist",
        pastTense: "unwhitelisted",
    }),
];
