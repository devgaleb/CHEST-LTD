import { ChannelType } from "discord.js";
import { isSnowflake, normalizeHttpUrl } from "../config";
import { print, printError } from "../log";
import { Color, respond, sendToLogChannel } from "../messages";
import { getConfig, getState, updateState } from "../settings";
import { Command, ranBy, slashCommand } from "./command";

const setHttpServer: Command = {
    data: slashCommand("set-http-server", "Sets the CommandBlock HTTP server to communicate to")
        .addStringOption((option) => option
            .setName("url")
            .setDescription("CommandBlock plugin address and port (example: http://127.0.0.1:25580)")
            .setRequired(true)),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const input = interaction.options.getString("url", true);
        const url = normalizeHttpUrl(input);

        if (url === null) {
            printError(`Failed to set ${input} as the HTTP server URL since it's not a valid URL.`);
            await respond(interaction,
                "The server URL provided is not valid. Please ensure it starts with `http://` or `https://`.",
                Color.Error);
            return;
        }

        updateState((state) => { state.httpServerUrl = url; });
        await respond(interaction, `CommandBlock HTTP server set to: ${url}`, Color.Success);
        await sendToLogChannel(interaction,
            `CommandBlock HTTP server set to: ${url}\n${ranBy(interaction, "Set by")}`,
            Color.Success);
    },
};

const setMcServer: Command = {
    data: slashCommand("set-mc-server", "Sets the IP the bot will display to users on Discord")
        .addStringOption((option) => option
            .setName("ip")
            .setDescription("IP address of your Minecraft server")
            .setRequired(true)),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const ip = interaction.options.getString("ip", true);

        updateState((state) => { state.mcServerIp = ip; });
        await respond(interaction, `Minecraft IP address set to: ${ip}`, Color.Success);
        await sendToLogChannel(interaction,
            `Minecraft IP address set to: ${ip}\n${ranBy(interaction, "Set by")}`,
            Color.Success);
    },
};

const addGuild: Command = {
    data: slashCommand("add-guild", "Adds a server ID to the list of servers the bot is allowed to be in")
        .addStringOption((option) => option
            .setName("guild-id")
            .setDescription("The ID of the server to add")
            .setRequired(true)),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const guildId = interaction.options.getString("guild-id", true).trim();

        if (!isSnowflake(guildId)) {
            await respond(interaction, `\`${guildId}\` is not a valid server ID.`, Color.Error);
            return;
        }

        if (guildId === getConfig().masterServerId) {
            await respond(interaction, `Guild ID ${guildId} is the bot's master server and is always allowed.`, Color.Error);
            return;
        }

        if (getState().allowedGuilds.includes(guildId)) {
            await respond(interaction, `Guild ID ${guildId} is already in the allowed guilds list.`, Color.Error);
            return;
        }

        updateState((state) => { state.allowedGuilds.push(guildId); });
        await respond(interaction, `Successfully added guild ID ${guildId} to the allowed guilds list.`, Color.Success);
        await sendToLogChannel(interaction,
            `Added guild ID ${guildId} to the allowed guilds list.\n${ranBy(interaction, "Added by")}`,
            Color.Success);
    },
};

const removeGuild: Command = {
    data: slashCommand("remove-guild", "Removes a server ID from the list of servers the bot is allowed to be in")
        .addStringOption((option) => option
            .setName("guild-id")
            .setDescription("The ID of the server to remove")
            .setRequired(true)),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const guildId = interaction.options.getString("guild-id", true).trim();

        if (guildId === getConfig().masterServerId) {
            await respond(interaction,
                `Guild ID ${guildId} is the bot's master server and can't be removed. ` +
                "Please contact the bot owner to change it.",
                Color.Error);
            return;
        }

        if (!getState().allowedGuilds.includes(guildId)) {
            await respond(interaction, `Guild ID ${guildId} is not in the allowed guilds list.`, Color.Error);
            return;
        }

        updateState((state) => {
            state.allowedGuilds = state.allowedGuilds.filter((id) => id !== guildId);
        });
        await respond(interaction, `Successfully removed guild ID ${guildId} from the allowed guilds list.`, Color.Success);
        await sendToLogChannel(interaction,
            `Removed guild ID ${guildId} from the allowed guilds list.\n${ranBy(interaction, "Removed by")}`,
            Color.Success);

        // Leave last, since the command may have been run from the server being removed.
        const guild = interaction.client.guilds.cache.get(guildId);
        if (!guild)
            return;

        try {
            await guild.leave();
            print(`Left guild ${guild.name} (ID: ${guild.id}) as it was removed from the allowed guilds list.`);
        } catch (err) {
            printError(`Bot failed to leave guild ${guild.name} (ID: ${guild.id}): ${(err as Error).message}`);
        }
    },
};

const addRole: Command = {
    data: slashCommand("add-role", "Adds a role to the list of allowed roles for admin commands")
        .addRoleOption((option) => option
            .setName("role")
            .setDescription("The role to add")
            .setRequired(true)),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const role = interaction.options.getRole("role", true);

        if (getState().allowedRoles.includes(role.id)) {
            await respond(interaction, `${role.name} is already in the allowed roles list.`, Color.Error);
            return;
        }

        updateState((state) => { state.allowedRoles.push(role.id); });
        await respond(interaction, `Successfully added ${role.name} to the allowed roles list.`, Color.Success);
        await sendToLogChannel(interaction,
            `Successfully added ${role.name} to the allowed roles list.\n${ranBy(interaction, "Added by")}`,
            Color.Success);
    },
};

const removeRole: Command = {
    data: slashCommand("remove-role", "Removes a role from the list of allowed roles for admin commands")
        .addRoleOption((option) => option
            .setName("role")
            .setDescription("The role to remove")
            .setRequired(true)),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const role = interaction.options.getRole("role", true);

        if (!getState().allowedRoles.includes(role.id)) {
            await respond(interaction, `${role.name} is not in the allowed roles list.`, Color.Error);
            return;
        }

        updateState((state) => {
            state.allowedRoles = state.allowedRoles.filter((id) => id !== role.id);
        });
        await respond(interaction, `Successfully removed role ${role.name} from the allowed roles list.`, Color.Success);
        await sendToLogChannel(interaction,
            `Removed role ${role.name} from the allowed roles list.\n${ranBy(interaction, "Removed by")}`,
            Color.Success);
    },
};

const setLoggingChannel: Command = {
    data: slashCommand("set-logging-channel", "Sets the channel where important messages are sent when commands are run")
        .addChannelOption((option) => option
            .setName("channel")
            .setDescription("The channel to send logs to")
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const channel = interaction.options.getChannel("channel", true, [ChannelType.GuildText]);

        updateState((state) => { state.loggingChannelId = channel.id; });
        print(`Successfully set logging channel to ${channel.name} (ID: ${channel.id})`);

        await respond(interaction, `Successfully saved <#${channel.id}> as the logging channel!`, Color.Success);
        await sendToLogChannel(interaction,
            `Set logging channel to this channel!\n${ranBy(interaction, "Set by")}`,
            Color.Success);
    },
};

const removeLoggingChannel: Command = {
    data: slashCommand("remove-logging-channel", "Removes the logging channel and disables logging on Discord"),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        if (getState().loggingChannelId === null) {
            await respond(interaction, "There is no logging channel set.", Color.Error);
            return;
        }

        // Leave a note in the old channel so it's clear why logs stopped.
        await sendToLogChannel(interaction,
            `Logging on Discord has been disabled.\n${ranBy(interaction, "Disabled by")}`,
            Color.Success);

        updateState((state) => { state.loggingChannelId = null; });
        print("Successfully removed logging channel");

        await respond(interaction, "Successfully removed the logging channel!", Color.Success);
    },
};

export const managementCommands: Command[] = [
    setHttpServer,
    setMcServer,
    addGuild,
    removeGuild,
    addRole,
    removeRole,
    setLoggingChannel,
    removeLoggingChannel,
];
