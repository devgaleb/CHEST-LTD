import { Command } from "./command";
import { managementCommands } from "./management";
import { moderationCommands } from "./moderation";
import { serverCommands } from "./server";

export const commands: Command[] = [
    ...managementCommands,
    ...serverCommands,
    ...moderationCommands,
];
