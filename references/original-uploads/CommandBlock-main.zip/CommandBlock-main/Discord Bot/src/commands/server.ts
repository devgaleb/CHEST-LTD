import { spawn } from "node:child_process";
import fs from "node:fs";
import { EmbedBuilder } from "discord.js";
import { describeStatus, sendGet, sendPost } from "../http";
import { print, printError } from "../log";
import { Color, respond, sendToLogChannel } from "../messages";
import { getConfig, getMcServerIp } from "../settings";
import { Command, ranBy, slashCommand } from "./command";

/** How long to watch the start command for an immediate failure. */
const START_CHECK_MS = 2000;

/** Discord's limit for an embed field value. */
const FIELD_VALUE_LIMIT = 1024;

/**
 * Runs the start command detached from the bot so the Minecraft server keeps running
 * if the bot stops. Resolves with an error message if the command fails right away.
 */
function launchServer(command: string, cwd: string): Promise<string | null> {
    return new Promise((resolve) => {
        const child = spawn(command, {
            cwd,
            shell: true,
            detached: true,
            stdio: "ignore",
        });

        const timer = setTimeout(() => {
            child.removeAllListeners();
            child.unref();
            resolve(null); // Still running, so it started.
        }, START_CHECK_MS);

        child.once("error", (err) => {
            clearTimeout(timer);
            resolve(err.message);
        });

        child.once("exit", (code) => {
            clearTimeout(timer);
            // Commands like "systemctl start" exit right away when they succeed.
            resolve(code === 0 ? null : `The start command exited with code ${code}.`);
        });
    });
}

const startServer: Command = {
    data: slashCommand("start-server", "Starts the Minecraft server"),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const { serverStartCommand, serverStartDirectory } = getConfig();

        if (!serverStartCommand) {
            await respond(interaction,
                "Failed to start server. Please contact server admins. More info is in my log!",
                Color.Error);
            printError("Cannot start server because SERVER_START_COMMAND is not set in config.env.");
            await sendToLogChannel(interaction,
                "Failed to start server. No start command is set.\n" +
                `Set SERVER_START_COMMAND in the bot's config.env and restart the bot.\n${ranBy(interaction)}`,
                Color.Error);
            return;
        }

        // The server must not be online to start it.
        const status = await sendGet("/server/stats", true);
        if (status.ok) {
            await respond(interaction, "Error starting server.\nThe server is already online!", Color.Error);
            printError("There was an error starting the server. The server is already online.");
            await sendToLogChannel(interaction,
                `Failed to start server. Server is already online.\n${ranBy(interaction)}`,
                Color.Error);
            return;
        }

        const error = fs.existsSync(serverStartDirectory)
            ? await launchServer(serverStartCommand, serverStartDirectory)
            : `SERVER_START_DIRECTORY "${serverStartDirectory}" does not exist.`;

        if (error !== null) {
            await respond(interaction,
                "Failed to start server. Please contact server admins. More info is in my log!",
                Color.Error);
            printError(`Failed to start server. ${error}`);
            await sendToLogChannel(interaction,
                `Failed to start server. ${error}\n${ranBy(interaction)}`,
                Color.Error);
            return;
        }

        await respond(interaction, "Successfully started server!", Color.Success);
        print("Successfully started server!");
        await sendToLogChannel(interaction, `Successfully started server!\n${ranBy(interaction)}`, Color.Success);
    },
};

const stopServer: Command = {
    data: slashCommand("stop-server", "Gracefully stops the Minecraft server"),
    admin: true,
    ephemeral: true,
    async execute(interaction) {
        const response = await sendPost("/server/stop");

        if (response.ok) {
            await respond(interaction, "Successfully stopped server!", Color.Success);
            print("Successfully stopped server!");
            await sendToLogChannel(interaction, `Server was stopped.\n${ranBy(interaction)}`, Color.Success);
        } else if (response.status === 401) {
            await respond(interaction,
                "Error stopping server.\nI'm not configured properly! Please contact server admins. More info is in my log!",
                Color.Error);
            printError("There was an error stopping the server. The request sent to the Minecraft server was unauthorized. " +
                "Please ensure your API tokens match.");
            await sendToLogChannel(interaction,
                "Failed to stop server. The request was unauthorized. " +
                "Please ensure the bot's API token matches the CommandBlock plugin's API token.\n" +
                ranBy(interaction),
                Color.Error);
        } else {
            const status = describeStatus(response.status);
            await respond(interaction, "Error stopping server.\nThe server may already be offline!", Color.Error);
            printError(`There was an error stopping the server. The server may already be offline. Status code: ${status}`);
            await sendToLogChannel(interaction,
                `Failed to stop server. The server may already be offline. Status code: ${status}\n${ranBy(interaction)}`,
                Color.Error);
        }
    },
};

interface ServerStatsData {
    gameVersion: string;
    uptime: string;
    onlinePlayers: number;
    maxPlayers: number;
    tps: number;
    playerList: string[];
}

function parseServerStats(body: string): ServerStatsData | null {
    try {
        const data = JSON.parse(body);
        if (typeof data !== "object" || data === null)
            return null;

        return {
            gameVersion: String(data.gameVersion ?? "Unknown"),
            uptime: String(data.uptime ?? "Unknown"),
            onlinePlayers: Number(data.onlinePlayers ?? 0),
            maxPlayers: Number(data.maxPlayers ?? 0),
            tps: Number(data.tps ?? 0),
            playerList: Array.isArray(data.playerList) ? data.playerList.map(String) : [],
        };
    } catch {
        return null;
    }
}

function truncate(text: string, limit: number): string {
    return text.length <= limit ? text : text.slice(0, limit - 3) + "...";
}

function serverStatsMessage(data: ServerStatsData | null): EmbedBuilder {
    const embed = new EmbedBuilder().setTitle("Server Stats");
    const ip = `**IP:** \`${getMcServerIp()}\``;

    if (data === null) {
        return embed
            .setColor(Color.Offline)
            .setDescription(`${ip}\n**Status:** 🔴 Offline`);
    }

    const players = data.playerList.length === 0 ? "No players online" : data.playerList.join("\n");

    return embed
        .setColor(Color.Success)
        .setDescription(`${ip}\n**Status:** 🟢 Online\n**Version:** ${data.gameVersion}`)
        .addFields(
            { name: "Player List", value: truncate(players, FIELD_VALUE_LIMIT), inline: true },
            { name: "Online/Max Players", value: `${data.onlinePlayers} / ${data.maxPlayers}`, inline: true },
            { name: "Uptime", value: data.uptime || "Unknown", inline: true },
            { name: "TPS (~20 is best)", value: data.tps.toFixed(3), inline: true },
        );
}

const serverStats: Command = {
    data: slashCommand("server-stats", "Gets the Minecraft server's statistics"),
    admin: false,
    ephemeral: false,
    async execute(interaction) {
        const response = await sendGet("/server/stats");

        // For the user, display that the server is offline. Detailed errors are in the log.
        if (!response.ok) {
            await interaction.editReply({ embeds: [serverStatsMessage(null)] });
            printError(`Failed to retrieve the server's stats. Status code: ${describeStatus(response.status)} ${response.body}`);
            return;
        }

        const stats = parseServerStats(response.body);
        if (stats === null)
            printError("Failed to retrieve the server's stats. The response was not valid JSON.");

        await interaction.editReply({ embeds: [serverStatsMessage(stats)] });
    },
};

export const serverCommands: Command[] = [
    startServer,
    stopServer,
    serverStats,
];
