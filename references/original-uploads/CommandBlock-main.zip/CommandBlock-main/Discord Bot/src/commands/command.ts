import { ChatInputCommandInteraction, InteractionContextType, SlashCommandBuilder, SlashCommandOptionsOnlyBuilder } from "discord.js";

export interface Command {
    data: SlashCommandBuilder | SlashCommandOptionsOnlyBuilder;
    /** Admin commands require the Administrator permission or an allowed role. */
    admin: boolean;
    /** Whether the reply is only visible to the user who ran the command. */
    ephemeral: boolean;
    /** Runs after the reply has been deferred, so respond with editReply. */
    execute(interaction: ChatInputCommandInteraction<"cached">): Promise<void>;
}

/** Starts a slash command definition that can only be used inside servers. */
export function slashCommand(name: string, description: string): SlashCommandBuilder {
    return new SlashCommandBuilder()
        .setName(name)
        .setDescription(description)
        .setContexts(InteractionContextType.Guild);
}

/** Mentions the user who ran the command, for logging channel messages. */
export function ranBy(interaction: ChatInputCommandInteraction, label = "Ran by"): string {
    return `${label}: <@${interaction.user.id}>`;
}
