import { print, printError } from "./log";
import { getConfig, getHttpServerUrl } from "./settings";

/** How long to wait for the CommandBlock plugin before giving up. */
const REQUEST_TIMEOUT_MS = 10_000;

export interface PluginResponse {
    /** The HTTP status code, or 0 if the plugin could not be reached. */
    status: number;
    ok: boolean;
    /** The raw response body. */
    body: string;
    /** The "error" field of a JSON response, or a connection error. Blank if none. */
    error: string;
}

/** Describes a status for logs, e.g. "401" or "no response". */
export function describeStatus(status: number): string {
    return status === 0 ? "no response" : status.toString();
}

function readErrorField(body: string): string {
    try {
        const json = JSON.parse(body);
        return typeof json?.error === "string" ? json.error : "";
    } catch {
        return ""; // Not JSON, so there is no error field.
    }
}

async function sendRequest(method: "GET" | "POST", endpoint: string, silent: boolean): Promise<PluginResponse> {
    const url = getHttpServerUrl() + endpoint;

    try {
        const response = await fetch(url, {
            method,
            headers: { Authorization: `Bearer ${getConfig().pluginApiToken}` },
            signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
        });
        const body = await response.text();

        if (!silent) {
            print(`Status: ${response.status}`);
            print(`Response: ${body}`);
        }

        return { status: response.status, ok: response.ok, body, error: readErrorField(body) };
    } catch (err) {
        const reason = (err as Error).name === "TimeoutError"
            ? `the request timed out after ${REQUEST_TIMEOUT_MS / 1000} seconds`
            : ((err as Error).cause as Error | undefined)?.message ?? (err as Error).message;

        if (!silent)
            printError(`A connection error occurred while sending an HTTP ${method} request to ${url}: ${reason}`);

        return { status: 0, ok: false, body: "", error: "The Minecraft server could not be reached." };
    }
}

export function sendGet(endpoint: string, silent = false): Promise<PluginResponse> {
    return sendRequest("GET", endpoint, silent);
}

export function sendPost(endpoint: string): Promise<PluginResponse> {
    return sendRequest("POST", endpoint, false);
}
