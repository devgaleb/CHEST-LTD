import { ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { printWarn } from "./log";
import { getState } from "./settings";

/** Embed colors, matching the original bot. */
export const Color = {
    Success: 0x2ecc71,
    Error: 0xe74c3c,
    Offline: 0x23272a,
} as const;

export function simpleMessage(message: string, color: number): EmbedBuilder {
    return new EmbedBuilder().setDescription(message).setColor(color);
}

/** Replies to a deferred interaction with a simple embed. */
export async function respond(interaction: ChatInputCommandInteraction, message: string, color: number): Promise<void> {
    await interaction.editReply({ embeds: [simpleMessage(message, color)] });
}

/** Sends a message to the logging channel, if one is set. */
export async function sendToLogChannel(interaction: ChatInputCommandInteraction, message: string, color: number): Promise<void> {
    const channelId = getState().loggingChannelId;
    if (channelId === null)
        return;

    try {
        const channel = await interaction.client.channels.fetch(channelId);
        if (channel?.isSendable())
            await channel.send({ embeds: [simpleMessage(message, color)] });
        else
            printWarn(`The logging channel (ID: ${channelId}) is not a channel the bot can send messages in.`);
    } catch (err) {
        printWarn(`Failed to send a message to the logging channel (ID: ${channelId}): ${(err as Error).message}`);
    }
}
