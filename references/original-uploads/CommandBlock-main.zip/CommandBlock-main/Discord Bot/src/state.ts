import fs from "node:fs";
import path from "node:path";
import { BOT_ROOT, ConfigError } from "./config";

const STATE_PATH = path.join(BOT_ROOT, "data.json");

/** Settings changed from Discord. Managed by the bot, so users should not need to edit it. */
export interface State {
    /** Extra servers the bot may be in, in addition to MASTER_SERVER_ID. */
    allowedGuilds: string[];
    /** Roles allowed to run admin commands, in addition to administrators. */
    allowedRoles: string[];
    loggingChannelId: string | null;
    /** Overrides HTTP_SERVER_URL when set with /set-http-server. */
    httpServerUrl: string | null;
    /** Overrides MC_SERVER_IP when set with /set-mc-server. */
    mcServerIp: string | null;
}

function defaultState(): State {
    return {
        allowedGuilds: [],
        allowedRoles: [],
        loggingChannelId: null,
        httpServerUrl: null,
        mcServerIp: null,
    };
}

export function loadState(): State {
    if (!fs.existsSync(STATE_PATH)) {
        const state = defaultState();
        saveState(state);
        return state;
    }

    let parsed: unknown;
    try {
        parsed = JSON.parse(fs.readFileSync(STATE_PATH, "utf8"));
    } catch (err) {
        throw new ConfigError(`data.json is malformed and could not be read: ${(err as Error).message}`);
    }

    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed))
        throw new ConfigError("data.json is malformed. It must contain a JSON object.");

    // Fill in anything missing so older or hand-edited files still load.
    return { ...defaultState(), ...(parsed as Partial<State>) };
}

/** Writes the state to disk atomically so a crash can never leave a half-written file. */
export function saveState(state: State): void {
    const tempPath = `${STATE_PATH}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(state, null, 4) + "\n");
    fs.renameSync(tempPath, STATE_PATH);
}
