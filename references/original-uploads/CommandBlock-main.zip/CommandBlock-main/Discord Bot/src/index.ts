import fs from "node:fs";
import path from "node:path";
import { Client, Events, GatewayIntentBits, Guild } from "discord.js";
import { BOT_ROOT, CONFIG_ERROR_EXIT_CODE, ConfigError } from "./config";
import { handleInteraction, registerCommands } from "./interactions";
import { print, printError, printRaw, printWarn } from "./log";
import { getConfig, initSettings, isGuildAllowed } from "./settings";

const version: string = JSON.parse(fs.readFileSync(path.join(BOT_ROOT, "package.json"), "utf8")).version;

/** Leaves the guild if it is not the master server or in the allowed guilds list. */
async function enforceGuildAllowlist(guild: Guild): Promise<void> {
    if (isGuildAllowed(guild.id)) {
        print(`Verified membership in allowed guild: ${guild.name} (ID: ${guild.id})`);
        return;
    }

    try {
        await guild.leave();
        printWarn(`Guild ${guild.name} (ID: ${guild.id}) is not in the allowed guilds list and the bot left it successfully.`);
    } catch (err) {
        printError(`Guild ${guild.name} (ID: ${guild.id}) is not in the allowed guilds list and the bot failed to leave: ${(err as Error).message}`);
    }
}

/**
 * Reports a configuration problem and sets the exit code PM2 will not restart on.
 * The process then exits on its own once open handles close, which avoids a libuv
 * crash on Windows when process.exit() runs while network handles are closing.
 */
function failWithConfigError(err: ConfigError): void {
    printError(err.message);
    process.exitCode = CONFIG_ERROR_EXIT_CODE;
}

async function main(): Promise<void> {
    printRaw(`\nCommandBlock Discord Bot\nVersion ${version}\n`);

    print("Loading config...");
    try {
        initSettings();
    } catch (err) {
        if (!(err instanceof ConfigError))
            throw err;
        failWithConfigError(err);
        return;
    }

    const client = new Client({ intents: [GatewayIntentBits.Guilds] });

    client.once(Events.ClientReady, async (readyClient) => {
        print(`Connected as ${readyClient.user.tag}.`);

        for (const guild of readyClient.guilds.cache.values())
            await enforceGuildAllowlist(guild);

        try {
            await registerCommands(readyClient);
        } catch (err) {
            printError(`Failed to register slash commands: ${(err as Error).message}`);
        }
    });

    client.on(Events.GuildCreate, async (guild) => {
        print(`Joined guild: ${guild.name} (ID: ${guild.id})`);
        await enforceGuildAllowlist(guild);
    });

    client.on(Events.InteractionCreate, handleInteraction);

    client.on(Events.Error, (err) => printError(`Discord client error: ${err.message}`));

    const shutdown = async (signal: string) => {
        printWarn(`Received ${signal}. Shutting down CommandBlock Discord Bot...`);
        await client.destroy();
        print("CommandBlock Discord Bot has successfully shut down.");

        // The process should exit on its own now. Force it if something is still holding it open.
        setTimeout(() => process.exit(0), 3000).unref();
    };
    process.once("SIGINT", () => void shutdown("SIGINT"));
    process.once("SIGTERM", () => void shutdown("SIGTERM"));

    print("Connecting to Discord...");
    try {
        await client.login(getConfig().discordToken);
    } catch (err) {
        await client.destroy();
        if ((err as { code?: string }).code !== "TokenInvalid")
            throw err;
        failWithConfigError(new ConfigError("Failed to connect to Discord: DISCORD_TOKEN in config.env is invalid."));
    }
}

main().catch((err) => {
    printError(`Fatal error: ${(err as Error).stack ?? err}`);
    process.exitCode = 1;
});
