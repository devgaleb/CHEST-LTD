import { EnvConfig, loadEnvConfig } from "./config";
import { State, loadState, saveState } from "./state";

let config: EnvConfig;
let state: State;

/** Loads config.env and data.json. Throws ConfigError if either is invalid. */
export function initSettings(): void {
    config = loadEnvConfig();
    state = loadState();
}

export function getConfig(): EnvConfig {
    return config;
}

export function getState(): Readonly<State> {
    return state;
}

/** Applies a change to the state and saves it to data.json. */
export function updateState(change: (state: State) => void): void {
    change(state);
    saveState(state);
}

/** The master server followed by any extra allowed servers. */
export function getAllowedGuildIds(): string[] {
    return [config.masterServerId, ...state.allowedGuilds];
}

export function isGuildAllowed(guildId: string): boolean {
    return getAllowedGuildIds().includes(guildId);
}

export function getHttpServerUrl(): string {
    return state.httpServerUrl ?? config.httpServerUrl;
}

export function getMcServerIp(): string {
    return state.mcServerIp ?? config.mcServerIp;
}
