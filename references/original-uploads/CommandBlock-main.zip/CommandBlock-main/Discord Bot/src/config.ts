import fs from "node:fs";
import path from "node:path";

/** The bot's folder (the one containing package.json), regardless of the working directory. */
export const BOT_ROOT = path.resolve(__dirname, "..");

const CONFIG_PATH = path.join(BOT_ROOT, "config.env");
const CONFIG_EXAMPLE_PATH = path.join(BOT_ROOT, "config.env.example");

export const DEFAULT_HTTP_SERVER_URL = "http://127.0.0.1:25580";
export const DEFAULT_MC_SERVER_IP = "Not set :P";

/** Exit code used for configuration problems. PM2 is told not to restart on it. */
export const CONFIG_ERROR_EXIT_CODE = 78;

/** An error caused by missing or invalid configuration. Restarting will not fix it. */
export class ConfigError extends Error {}

export interface EnvConfig {
    discordToken: string;
    masterServerId: string;
    pluginApiToken: string;
    httpServerUrl: string;
    mcServerIp: string;
    serverStartCommand: string;
    serverStartDirectory: string;
}

const SNOWFLAKE = /^\d{17,20}$/;

export function isSnowflake(value: string): boolean {
    return SNOWFLAKE.test(value);
}

/**
 * Validates an http(s) URL and returns it without a trailing slash,
 * or returns null if it is invalid.
 */
export function normalizeHttpUrl(value: string): string | null {
    let url: URL;
    try {
        url = new URL(value);
    } catch {
        return null;
    }

    if (url.protocol !== "http:" && url.protocol !== "https:")
        return null;

    return url.toString().replace(/\/+$/, "");
}

function readEnv(key: string): string {
    return process.env[key]?.trim() ?? "";
}

/** Loads and validates config.env, creating it from the example on first launch. */
export function loadEnvConfig(): EnvConfig {
    if (!fs.existsSync(CONFIG_PATH)) {
        fs.copyFileSync(CONFIG_EXAMPLE_PATH, CONFIG_PATH);
        throw new ConfigError(
            `config.env did not exist, so one was created at ${CONFIG_PATH}. ` +
            "Fill in the required values and start the bot again.");
    }

    process.loadEnvFile(CONFIG_PATH);

    const config: EnvConfig = {
        discordToken: readEnv("DISCORD_TOKEN"),
        masterServerId: readEnv("MASTER_SERVER_ID"),
        pluginApiToken: readEnv("PLUGIN_API_TOKEN"),
        httpServerUrl: readEnv("HTTP_SERVER_URL") || DEFAULT_HTTP_SERVER_URL,
        mcServerIp: readEnv("MC_SERVER_IP") || DEFAULT_MC_SERVER_IP,
        serverStartCommand: readEnv("SERVER_START_COMMAND"),
        serverStartDirectory: readEnv("SERVER_START_DIRECTORY") || BOT_ROOT,
    };

    const missing = [
        ["DISCORD_TOKEN", config.discordToken],
        ["MASTER_SERVER_ID", config.masterServerId],
        ["PLUGIN_API_TOKEN", config.pluginApiToken],
    ].filter(([, value]) => !value).map(([key]) => key);

    if (missing.length > 0)
        throw new ConfigError(`config.env is missing required values: ${missing.join(", ")}`);

    if (!isSnowflake(config.masterServerId))
        throw new ConfigError("MASTER_SERVER_ID in config.env is not a valid Discord server ID.");

    const httpServerUrl = normalizeHttpUrl(config.httpServerUrl);
    if (httpServerUrl === null)
        throw new ConfigError("HTTP_SERVER_URL in config.env must start with http:// or https://.");
    config.httpServerUrl = httpServerUrl;

    return config;
}
