const useColor = !process.env.NO_COLOR;

const RESET = "\x1b[0m";
const MAGENTA = "\x1b[35m";
const YELLOW = "\x1b[33m";
const RED = "\x1b[31m";

function color(code: string, text: string): string {
    return useColor ? `${code}${text}${RESET}` : text;
}

/** Formats the current time as MM/DD/YYYY hh:mm:ss AM/PM. */
function timestamp(): string {
    const now = new Date();
    const pad = (n: number) => n.toString().padStart(2, "0");
    const hours = now.getHours() % 12 || 12;
    const period = now.getHours() < 12 ? "AM" : "PM";

    return `${pad(now.getMonth() + 1)}/${pad(now.getDate())}/${now.getFullYear()} ` +
        `${pad(hours)}:${pad(now.getMinutes())}:${pad(now.getSeconds())} ${period}`;
}

/** Prints a message with no timestamp or tag. */
export function printRaw(message: unknown): void {
    console.log(message);
}

/** Prints a message with a timestamp and INFO tag. */
export function print(message: unknown): void {
    console.log(`[${timestamp()}] ${color(MAGENTA, "INFO:")} ${message}`);
}

/** Prints a message with a timestamp and WARN tag. */
export function printWarn(message: unknown): void {
    console.warn(`[${timestamp()}] ${color(YELLOW, "WARN:")} ${message}`);
}

/** Prints a message with a timestamp and ERROR tag. */
export function printError(message: unknown): void {
    console.error(`[${timestamp()}] ${color(RED, "ERROR:")} ${message}`);
}
