import { ChatInputCommandInteraction, Client, Collection, Interaction, MessageFlags, PermissionFlagsBits } from "discord.js";
import { Command } from "./commands/command";
import { commands } from "./commands";
import { print, printError } from "./log";
import { Color, simpleMessage } from "./messages";
import { getState } from "./settings";

const commandsByName = new Collection(commands.map((command) => [command.data.name, command]));

/** Replaces the bot's global slash commands with the current list. */
export async function registerCommands(client: Client<true>): Promise<void> {
    await client.application.commands.set(commands.map((command) => command.data.toJSON()));
    print(`Registered ${commands.length} slash commands.`);
}

function canRunAdminCommands(interaction: ChatInputCommandInteraction<"cached">): boolean {
    const member = interaction.member;
    if (member.permissions.has(PermissionFlagsBits.Administrator))
        return true;

    const allowedRoles = getState().allowedRoles;
    return member.roles.cache.some((role) => allowedRoles.includes(role.id));
}

async function runCommand(command: Command, interaction: ChatInputCommandInteraction<"cached">): Promise<void> {
    const who = `${interaction.user.username} (ID: ${interaction.user.id})`;
    const name = `/${interaction.commandName}`;

    if (command.admin && !canRunAdminCommands(interaction)) {
        print(`${who} tried to run ${name} but didn't have permission.`);
        await interaction.reply({
            embeds: [simpleMessage("You do not have permission to run this command.", Color.Error)],
            flags: MessageFlags.Ephemeral,
        });
        return;
    }

    print(`${who} is running ${name}.`);
    await interaction.deferReply(command.ephemeral ? { flags: MessageFlags.Ephemeral } : {});

    try {
        await command.execute(interaction);
    } catch (err) {
        printError(`An error occurred while running ${name}: ${(err as Error).stack ?? err}`);
        await interaction.editReply({
            embeds: [simpleMessage("An error occurred while running this command. Please contact server admins.", Color.Error)],
        }).catch(() => { /* The interaction may have expired. */ });
    }
}

export async function handleInteraction(interaction: Interaction): Promise<void> {
    if (!interaction.isChatInputCommand() || !interaction.inCachedGuild())
        return;

    const command = commandsByName.get(interaction.commandName);
    if (!command)
        return;

    try {
        await runCommand(command, interaction);
    } catch (err) {
        printError(`Failed to respond to /${interaction.commandName}: ${(err as Error).message}`);
    }
}
